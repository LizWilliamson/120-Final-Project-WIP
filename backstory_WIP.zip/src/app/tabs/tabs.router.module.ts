import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { TabsPage } from './tabs.page';

const routes: Routes = [
  {
    path: '',
    component: TabsPage,
    children: [
      {
        path: "feed",
        loadChildren: () =>
          import('../feed/feed.module').then(m => m.FeedPageModule)
          
      },

      {
        path: "discover",
        loadChildren: () =>
          import('../discover/discover.module').then(m => m.DiscoverPageModule)
      },

      {
        path: "upload",
        loadChildren: () =>
          import('../upload/upload.module').then(m => m.UploadPageModule)
      },

      {
        path: "notifications",
        loadChildren: () =>
          import('../notifications/notifications.module').then(m => m.NotificationsPageModule)
          
      },

      {
        path: "profile",
        loadChildren: () =>
          import('../profile/profile.module').then(m => m.ProfilePageModule)
      }

      
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes,)
  ],
  exports: [RouterModule]
})
export class TabsRoutingModule {}