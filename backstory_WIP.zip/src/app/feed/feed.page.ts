import { UserService } from './../user.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feed',
  templateUrl: './feed.page.html',
  styleUrls: ['./feed.page.scss'],
})
export class FeedPage implements OnInit {
  // posts: Post [] = [];

  // constructor(private user: UserService ) {
  //   console.log("Hey, here's some data from the service", this.user.getAllPosts());

  //   this.user.getAllPosts().subscribe(res +> {
  //     this.posts = [];
  //   })
  //  }

  ngOnInit() {
  }

}
