import { UserService } from './../user.service';
import { AngularFirestore } from '@angular/fire/firestore';
import { Component, OnInit } from '@angular/core';
import { firestore } from 'firebase/app';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.page.html',
  styleUrls: ['./upload.page.scss'],
})
export class UploadPage implements OnInit {

  story: string

  constructor(
      public afstore: AngularFirestore,
      public user: UserService
  ) { }

  ngOnInit() {
  }



  createPost(){
      const story = this.story
      const user=this.user

      this.afstore.doc(`users/${this.user.getUID()}`).update({
        posts: firestore.FieldValue.arrayUnion({
          story,
          user
        })
      })


  }
}
