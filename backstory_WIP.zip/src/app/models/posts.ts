export class Post {
    // class attributes
    public story: string;
    public from: string;
    public to: string;
    public createdOn: Date;

    // class methods

    constructor() {
        this.to = "Everyone";
        this.createdOn = new Date();
    }


}