export class Friend {

    public name: string;
    public belongsTo: string = "";
}